document.addEventListener("DOMContentLoaded", function () {
    const currencies = ["USD", "EUR", "RUB", "UZS", "GBP", "CNY", "JPY", "CAD", "AUD", "CHF", "SEK", "NOK", "MXN", "BRL", "ZAR", "KRW", "SGD", "NZD", "HKD", "TRY"];

    let fromSelect = document.getElementById("from_currency");
    let toSelect = document.getElementById("to_currency");

    currencies.forEach(currency => {
        let option1 = document.createElement("option");
        option1.value = currency;
        option1.textContent = currency;
        fromSelect.appendChild(option1);

        let option2 = document.createElement("option");
        option2.value = currency;
        option2.textContent = currency;
        toSelect.appendChild(option2);
    });
});

function convert() {
    let fromCurrency = document.getElementById("from_currency").value;
    let toCurrency = document.getElementById("to_currency").value;
    let amount = document.getElementById("amount").value;

    fetch(`/convert/?from_currency=${fromCurrency}&to_currency=${toCurrency}&amount=${amount}`)
        .then(response => response.json())
        .then(data => {
            document.getElementById("result").textContent = `${data.amount} ${data.from} → ${data.converted_amount} ${data.to}`;
        })
        .catch(error => console.log(error));
}
