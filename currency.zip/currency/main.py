from fastapi import FastAPI
from fastapi.staticfiles import StaticFiles
from fastapi.responses import FileResponse
import requests

app = FastAPI()

# Static fayllarni xizmat qilish
app.mount("/static", StaticFiles(directory="static"), name="static")

# Bosh sahifa
@app.get("/")
def read_root():
    return FileResponse("static/index.html")

# Valyuta kurslarini olish
@app.get("/convert/")
def convert_currency(from_currency: str, to_currency: str, amount: float):
    url = f"https://api.exchangerate-api.com/v4/latest/{from_currency}"
    response = requests.get(url)
    data = response.json()

    if to_currency not in data["rates"]:
        return {"error": "Noto‘g‘ri valyuta kodi!"}

    converted_amount = amount * data["rates"][to_currency]
    return {
        "from": from_currency,
        "to": to_currency,
        "amount": amount,
        "converted_amount": round(converted_amount, 2)
    }
